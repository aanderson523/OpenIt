package com.example.openit


import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_free_gallery.*
import kotlinx.android.synthetic.main.activity_main.*

class FreeGallery : AppCompatActivity() {

    var modelList = ArrayList<FreeGallery.Model>()

    class Model {
        var name:String? = null
        var image:Int? = null

        constructor( name:String, image:Int){
            this.name = name
            this.image = image
        }

    }

    var names = arrayOf(
        "img2",
        "img3",
        "img4",
        "img5",
        "img8"
    )
    var images = intArrayOf(
        R.drawable.img2,
        R.drawable.img3,
        R.drawable.img4,
        R.drawable.img5,
        R.drawable.img8,
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        for(i in names.indices){
            modelList.add(FreeGallery.Model(names[i],images[i]))
        }

        var customAdapter = CustomAdapter(modelList,this);

        gridView.adapter = customAdapter
    }



    class CustomAdapter(
        var itemModel: ArrayList<FreeGallery.Model>,
        var context: Context
    ) : BaseAdapter() {

        var layoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

        override fun getCount(): Int {

            return itemModel.size
        }

        override fun getItem(p0: Int): Any {

            return itemModel[p0]
        }

        override fun getItemId(p0: Int): Long {

            return p0.toLong()
        }

        override fun getView(postion: Int, view: View?, viewGroup: ViewGroup?): View {
            var view = view;
            if (view == null) {
                view = layoutInflater.inflate(R.layout.activity_free_gallery, viewGroup, false);
            }

            var tvImageName = view?.findViewById<TextView>(R.id.imageName)
            var imageView = view?.findViewById<ImageView>(R.id.imageView);

            tvImageName?.text = itemModel[postion].name;
            imageView?.setImageResource(itemModel[postion].image!!)

            return view!!

        }

    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu,menu)
        return true
    }



    override fun onOptionsItemSelected(item: MenuItem): Boolean{

        when (item.itemId) {
            R.id.FreeGalleryId -> {
                startActivity(Intent(this, FreeGallery::class.java))
                return super.onOptionsItemSelected(item) }
            else -> {
                return super.onOptionsItemSelected(item)
            }

        }
    }


}