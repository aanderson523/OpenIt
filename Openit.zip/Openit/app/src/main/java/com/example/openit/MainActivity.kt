package com.example.openit

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.Gallery
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu,menu)
        return true

        signupBtn.setOnClickListener {
            startActivity(Intent(this,Signup::class.java))
        }
        loginBtn.setOnClickListener {
            startActivity(Intent(this,Login::class.java))
        }
    }



    override fun onOptionsItemSelected(item: MenuItem): Boolean{

        when (item.itemId) {
            R.id.FreeGalleryId -> {
                startActivity(Intent(this, FreeGallery::class.java))
                return super.onOptionsItemSelected(item) }
            else -> {
                return super.onOptionsItemSelected(item)
            }

        }
    }


}