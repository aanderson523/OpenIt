package com.example.openit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Service : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_service)
    }
}